import { SafeAreaView, Text } from "react-native";


export default function WalletScreen() {
  return (
    <SafeAreaView>
      <Text>Wallet Screen</Text>
    </SafeAreaView>
  );
}
