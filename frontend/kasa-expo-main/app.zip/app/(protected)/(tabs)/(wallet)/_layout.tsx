import { Stack } from "expo-router";
import React from "react";

const WalletLayout = () => {
  return <Stack />;
};

export default WalletLayout;
